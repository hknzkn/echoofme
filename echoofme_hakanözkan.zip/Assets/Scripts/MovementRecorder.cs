using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementRecorder : MonoBehaviour
{
    public GameObject clonePrefab; // Klon karakter prefab�
    public float recordInterval = 0.1f;

    private List<Vector3> recordedPositions = new List<Vector3>();
    private bool isRecording = true;
    private float timer = 0f;

    public KeyCode spawnKey = KeyCode.R; // ayarlanabilir tu�

    void Update()
    {
        if (!isRecording) return;

        timer += Time.deltaTime;
        if (timer >= recordInterval)
        {
            recordedPositions.Add(transform.position);
            timer = 0f;
        }

        if (Input.GetKeyDown(spawnKey))
        {
            StopAndSpawnClone();
            // Resetle tekrar kay�t ba�lat
            isRecording = true;
            recordedPositions.Clear();
        }
    }



    public void StopAndSpawnClone()
    {
        isRecording = false;

        GameObject clone = Instantiate(clonePrefab, recordedPositions[0], Quaternion.identity);
        clone.AddComponent<MovementReplayer>().Init(new List<Vector3>(recordedPositions), recordInterval);

    }
}
