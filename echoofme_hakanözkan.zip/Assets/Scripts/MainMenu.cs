using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void StartGame()
    {
        SceneManager.LoadScene("Level1"); // ya da ilk oyun sahnene verdi�in ad
    }

    public void QuitGame()
    {
        Debug.Log("��k�l�yor...");
        Application.Quit();
    }
}
