using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiButtonDoor : MonoBehaviour
{
    public GameObject door;
    public ButtonTriggerZone button1;
    public ButtonTriggerZone button2;

    void Update()
    {
        if (button1.IsPressed && button2.IsPressed)
        {
            door.SetActive(false);
        }
    }
}
