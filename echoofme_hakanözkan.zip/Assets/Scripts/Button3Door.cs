using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Button3Door : MonoBehaviour
{
    public GameObject door;
    public ButtonTriggerZone button1;
    public ButtonTriggerZone button2;
    public ButtonTriggerZone button3;

    void Update()
    {
        if (button1.IsPressed && button2.IsPressed && button3.IsPressed)
        {
            door.SetActive(false);
        }
    }
}
