using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MovementReplayer : MonoBehaviour
{
    private List<Vector3> positions;
    private float interval;

    void Start()
    {
        GetComponent<SpriteRenderer>().color = Color.green;
    }

    public void Init(List<Vector3> recordedPositions, float timeInterval)
    {
        positions = recordedPositions;
        interval = timeInterval;
        StartCoroutine(Replay());
    }

    IEnumerator Replay()
    {
        foreach (Vector3 pos in positions)
        {
            transform.position = pos;
            yield return new WaitForSeconds(interval);
        }
    }
}

