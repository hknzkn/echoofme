using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonTriggerZone : MonoBehaviour
{
    public bool IsPressed { get; private set; }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") || other.CompareTag("Clone"))
        {
            IsPressed = true;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player") || other.CompareTag("Clone"))
        {
            IsPressed = false;
        }
    }
}
